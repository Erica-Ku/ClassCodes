package Chap6_정렬알고리즘;

public class Test_QuickSort_1 {
	//퀵 정렬(비재귀 버전)

		// --- 배열 요소 a[idx1]와 a[idx2]의 값을 교환 ---//
		static void swap(int[] a, int idx1, int idx2) {
			int t = a[idx1];
			a[idx1] = a[idx2];
			a[idx2] = t;
		}

		// --- 퀵 정렬(비재귀 버전)---//
		static void quickSort(int[] a, int left, int right) {
			QuickSort_Stack st = new QuickSort_Stack(10);
		    Point pt = new Point(left, right);
		    st.push(pt);
		    
		    while (!st.isEmpty()) {
		        Point p = st.pop();
		        left = p.getX();
		        right = p.getY();
		        
		        if (left < right) {
		            int pivotIndex = partition(a, left, right);
		            st.push(new Point(left, pivotIndex - 1));
		            st.push(new Point(pivotIndex + 1, right));
		        }
		    }
		}

		static int partition(int[] a, int left, int right) {
		    int pivotIndex = left;
		    int pivotValue = a[right];
		    for (int i = left; i < right; i++) {
		        if (a[i] < pivotValue) {
		            swap(a, i, pivotIndex);
		            pivotIndex++;
		        }
		    }
		    swap(a, pivotIndex, right);
		    return pivotIndex;
		}
			
		public static void main(String[] args) {
			int nx = 10;
			int[] x = new int[10];
			for (int ix = 0; ix < 10; ix++) {
				double d = Math.random();
				x[ix] = (int) (d * 20);
			}
			for (int i = 0; i < nx; i++)
				System.out.print(" " + x[i]);
			System.out.println();

			quickSort(x, 0, nx - 1); // 배열 x를 퀵정렬

			System.out.println("오름차순으로 정렬했습니다.");
			for (int i = 0; i < nx; i++)
				System.out.print(" " + x[i]);
		}
}