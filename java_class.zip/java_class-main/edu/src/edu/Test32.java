package edu;

public class Test32 {

	public static void main(String[] args) {
		int[] arr = {1,2,3,4,5};
		//for (int i = 0; i < 5; i++)
		//arr[i] = (i + 1) * 10;
		/*arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		arr[3] = 40;
		arr[4] = 50;*/
		
		//for (int i = 0; i < arr.length; i++)
		for(int num: arr)
		System.out.print(" " + num);
		System.out.println();
		
		/*System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(arr[3]);
		System.out.println(arr[4]);*/
	}
}