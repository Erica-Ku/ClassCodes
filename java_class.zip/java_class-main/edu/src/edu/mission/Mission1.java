package edu.mission;

public class Mission1 {

	public static void main(String[] args) {
		double a = 9.81;
		//int t = 5;
		int v0 = 0;
		int x0 = 0;
		//double l = (0.5*a*t*t) + (v0*t) + x0;
		//double l1 = 1000 - l;
		
		//System.out.printf("5초 후 위치 : " + "%.2f" + "m", l1);
		
		/*for(int t = 0; t < (t + 1); t++) {
			double l = (0.5*a*t*t) + (v0*t) + x0;
			double l1 = 1000 - l;*/
		}
	}