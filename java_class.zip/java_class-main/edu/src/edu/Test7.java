package edu;

public class Test7 {

	public static void main(String[] args) {
		int a = 10;
		a++;
		System.out.println(a);
		++a;
		System.out.println(a);
		
		int b = 10;
		b--;
		System.out.println(b);
		--b;
		System.out.println(b);
		
		int c = 10;
		int d = 10;
		System.out.println(++c);
		System.out.println(d++);
		System.out.println(d);
	}
}
