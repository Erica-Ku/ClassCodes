package edu;

public class Test2 {
	
	public static void main(String[] args) {
		int depositAmount;
		depositAmount = 50000;
		System.out.printf("%d\n", depositAmount);
		
		int depositAmount1;
		depositAmount1 = 20000;
		System.out.printf("%d\n", depositAmount1);
	}

}
