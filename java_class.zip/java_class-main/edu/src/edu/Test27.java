package edu;

public class Test27 {

	public static void main(String[] args) {
		for(int i = 10; i < 10; i++) {
			System.out.println("for OK");
		}
		
		int j = 10;
		while(j < 10) {
			System.out.println("while OK");
			j++;
		}
		
		int k = 10;
		do {
			System.out.println("do-while OK");
			k++;
		} while(k < 10);
	}
}