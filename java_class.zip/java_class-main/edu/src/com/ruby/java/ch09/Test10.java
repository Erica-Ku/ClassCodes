package com.ruby.java.ch09;

public class Test10 {

	public static void main(String[] args) {
		System.out.println(Math.E);
		System.out.println(Math.PI);
		System.out.println(Math.abs(-12));
		System.out.println(Math.ceil(12.5));
		System.out.println(Math.floor(12.5));
		System.out.println(Math.max(5,8));
		System.out.println(Math.min(5,8));
		System.out.println(Math.pow(2,3));
		System.out.println(Math.random());
		System.out.println(Math.round(12.5));
		System.out.println(Math.sqrt(4));
	}
}