package com.ruby.java.test1;

public class Armor {
	private String name;
    private int height;
    
    public String getName() {
    	return name;
    }
    
    public void setHeight (int value) {
	 height = value;
    }
    public void setName () {
    	String value = "mark6";
        name = value;
    }
}