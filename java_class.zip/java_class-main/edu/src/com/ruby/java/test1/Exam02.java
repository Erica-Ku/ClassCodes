package com.ruby.java.test1;

public class Exam02 {

}
