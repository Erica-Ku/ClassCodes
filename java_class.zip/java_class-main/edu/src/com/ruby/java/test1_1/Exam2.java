package com.ruby.java.test1_1;

class sample {
	private int a;
}
public class Exam2 {

	public static void main(String[] args) {
		Exam2 ex = new Exam2();
		sample s = new sample();
		s.a = 10;
	}
}