package com.ruby.jave.test2;

public class Exam04 {

}
